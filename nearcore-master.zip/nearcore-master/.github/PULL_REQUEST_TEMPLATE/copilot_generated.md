### WHAT
copilot:summary
​
copilot:poem

### WHY
<!-- author to complete -->

### HOW
copilot:walkthrough
