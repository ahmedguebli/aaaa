mod async_component;
mod async_component_test;
mod multi_instance_test;
mod sum_numbers;
mod sum_numbers_test;
mod timed_component;
mod timed_component_test;
