# Changelog

## 0.1.1

* Fixed duplicate transaction identifiers in Data API

## 0.1.0

* Data API exposes feature-complete balance-changing operations
* Construction API exposes the bare minimum signed transaction submittion API
