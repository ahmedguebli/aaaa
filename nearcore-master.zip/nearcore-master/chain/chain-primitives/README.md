# near-chain-primitives

This crate hosts NEAR chain-related error types.