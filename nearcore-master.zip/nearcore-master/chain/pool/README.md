# near-pool crate

This crate holds TransactionPool (with PoolIterator), that is used to keep track of transactions that were not yet accepted into the blockchain.