# near-chunk-primitives

This crate hosts NEAR chunks-related error types.