# near-indexer-primitives

This crate holds the types that is used in NEAR Indexer Framework to allow other projects to use them without a need to depend on entire `nearcore`.
